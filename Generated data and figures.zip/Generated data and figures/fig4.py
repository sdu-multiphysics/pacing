import matplotlib
from matplotlib import pyplot as plt
import scienceplots
plt.style.use('science')
import numpy as np
import pandas as pd



file = 'fig6(MTM).csv' # initial guess is MTM strategy (his data is at optSolInd=0)
file_const = 'fig6(optimal).csv' # initial guess is a constant strategy as usual. Optimal strategy is at optSolInd=13

df = pd.read_csv(file, header=7)
dfconst = pd.read_csv(file_const, header=7)


x_ax = df['x (m) @ optSolInd=13']/1000 # conversion from m to km
height = df['height(x) (m) @ optSolInd=13']
maxvel = df['v (m/s) @ optSolInd=0'].max()
maxP = max([df['Pout (W) @ optSolInd=0'].max(), dfconst['Pout (W) @ optSolInd=13'].max()])



fig, ax1 = plt.subplots()
ax2 = ax1.twinx()

fig.set_size_inches(2*3.5, 2.625) # same height as others but twice the width


tabcolors = ['tab:blue', 'tab:green', 'tab:red', 'tab:orange', 'tab:brown']
basecolors = ['k', 'b', 'g', 'r', 'c']
lwidth = .5
fsize=8
fade=.4

# BASE - GRID AND AXIS
###################################

ax1.grid(linewidth=.3, alpha=.3, linestyle='--', which='both')
ax1.set_xlabel('Distance [km]', fontsize=fsize, labelpad=2.0)
ax1.ticklabel_format(axis='y', style='scientific', scilimits=(0, 1000))

ymax = (14/13)*maxP
ax1.set_ylim([(0/8)*maxP, ymax])
ax1.set_ylabel('Power [W]', fontsize=fsize, labelpad=2.0)

legend_loc = (.25, .8)
legend_loc_2 = (.05, .77)

ytop = .93

# PLOT 1 - HILL
########################################################

maxheight = height.max()
maxheight_arg = height.argmax()
minheight = height.min()
minheight_arg = height.argmin()


ax2.fill_between(x_ax, height, alpha=.1, color='dimgray')
ax2.set_ylim([-(0/3)*maxheight, (9/3)*maxheight])
ax2.get_yaxis().set_visible(False)


sfsize=fsize-2
alph = .8

peaktext = ax2.text(x=x_ax[maxheight_arg]-.5, y=maxheight, s='{:.0f} [m]'.format(maxheight), fontsize=sfsize, color='dimgray', alpha=alph)
troughtext = ax2.text(x=x_ax[minheight_arg]-.5, y=minheight, s='{:.0f} [m]'.format(minheight), fontsize=sfsize, color='dimgray', alpha=alph)



ax3 = ax1.twinx() # Velocity axis
ax3.set_ylabel(r'$\,$', fontsize=fsize, labelpad=10.0)
ax3.set_ylim([(-0/3)*maxvel, (14/13)*maxvel])
ax3.get_yaxis().set_visible(False)



# PLOT
####################################

smooth = df['Pout (W) @ optSolInd=0'].rolling(100).mean() # 100 about 53 m

# CONSTANT
PlotCPSpower, = ax1.plot(x_ax, dfconst['Pout (W) @ optSolInd=0'], color='r', lw=lwidth, alpha=1)

# Martin Toft Madsen
PlotMTMpower, = ax1.plot(x_ax, smooth, color='b', lw=lwidth, alpha=fade)

# OPTIMAL
PlotOPSpower, = ax1.plot(x_ax, df['Pout (W) @ optSolInd=13'], color='k', lw=lwidth)


# TIME STAMPS AND CONSTRAINT VALUE
##########################################
x20, y2max = ax2.get_xlim()[1], ax2.get_ylim()[1]

ytop = .921
xdiff = .2
xcenter=.515

toptext =  ax3.text(x=xcenter, y=ytop, s=r'$f_\mathrm{{bench.}} = {:.0f}\, \mathrm{{s}} \qquad \qquad f_\mathrm{{Madsen}} = {:.0f}\, \mathrm{{s}} \qquad \qquad f_\mathrm{{opt.}} = {:.0f}\, \mathrm{{s}} $'
                        .format(dfconst['T (s) @ optSolInd=0'][0], df['T (s) @ optSolInd=0'][0], df['T (s) @ optSolInd=13'][0]),
                        ha='center', va='top', transform=fig.transFigure, fontsize=fsize)



# TEXT POWER AND VELCOCITY
########################################
xpos1 = .35
xpos2 = 1.1


TextCPSpower = ax1.text(x=17, y=405, s='Benchmark power', color='r', fontsize=sfsize, alpha=1)
TextMTMpower = ax1.text(x=7.2, y=570, s=r'\noindent Pro cyclist Madsen'+'\''+'s power', color='b', fontsize=sfsize, alpha=fade)
TextOPSpower = ax1.text(x=1.2, y=460, s='Optimized power', color='k', fontsize=sfsize, alpha=1)



plt.savefig('fig6.pdf', dpi=1600)
