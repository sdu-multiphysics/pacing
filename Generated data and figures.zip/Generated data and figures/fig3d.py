from matplotlib import pyplot as plt
import scienceplots
plt.style.use('science')
import numpy as np
import pandas as pd



file = 'fig5d.csv'
df = pd.read_csv(file, header=7)



x_ax = df['x (m) @ optSolInd=23']/1000 # conversion from m to km
height = df['height(x) (m) @ optSolInd=23']
maxheight = height.max()
maxvel = df['v (m/s) @ optSolInd=0'].max()
maxP = df['Pout (W) @ optSolInd=23'].max()



fig, ax1 = plt.subplots() #Power axis
ax2 = ax1.twinx() # Height axis
ax3 = ax1.twinx() # Velocity axis


tabcolors = ['tab:blue', 'tab:green', 'tab:red', 'tab:orange', 'tab:brown']
basecolors = ['k', 'b', 'g', 'r', 'c']
lwidth = .5
fsize=8
sfsize=6
fade=.4


# BASE - GRID AND AXIS
###################################

ax1.grid(linewidth=.3, alpha=.3, linestyle='--', which='both')
ax1.set_xlabel('Distance [km]', fontsize=fsize, labelpad=2.0)
ax1.ticklabel_format(axis='y', style='scientific', scilimits=(0, 100))

ymax = (7/6)*maxP
ax1.set_ylim([(0/8)*maxP, ymax])
ax1.set_ylabel('Power [W]', fontsize=fsize, labelpad=2.0)


ax3.set_ylabel('Velocity [m/s]', fontsize=fsize, labelpad=2.0)
ax3.set_ylim([(-0/3)*maxvel, (28/25)*maxvel])


# PLOT 1 - HILL
########################################################

ax2.fill_between(x_ax, [1 for x in x_ax], alpha=.1, color='dimgray')
ax2.set_ylim([0, 7/3])
ax2.get_yaxis().set_visible(False)


sfsize=fsize-2
alph = .8
ax2.text(x=1.6, y=1.04, s='0 [m]', fontsize=sfsize, color='dimgray', alpha=alph)

# arrows
hwidth=.05
hlength=.025
xs = .02
yar = 1.04


ax2.arrow(x=.5+xs, y=yar, dx=+(.5-2*xs-hlength), dy=0, linewidth=lwidth, color='dimgray',
            alpha=alph, head_width=hwidth, head_length=hlength)

ax2.text(x=.65, y=yar+.03, s='5 m/s', fontsize=sfsize, color='dimgray', alpha=alph)

ax2.arrow(x=1.5-xs, y=yar, dx=-(.5-2*xs-hlength), dy=0, linewidth=lwidth, color='dimgray',
            alpha=alph, head_width=hwidth, head_length=hlength)

ax2.text(x=1.15, y=yar+.03, s='5 m/s', fontsize=sfsize, color='dimgray', alpha=alph)


# PLOTS
#########################################

# CONSTANT
PlotCPSpower, = ax1.plot(x_ax, df['Pout (W) @ optSolInd=0'], color=basecolors[0], lw=lwidth, alpha=fade)
PlotCPSvelocity, = ax3.plot(x_ax, df['v (m/s) @ optSolInd=0'], label='Velocity', color=basecolors[1], lw=lwidth, alpha=fade)

# OPTIMAL
PlotOPSpower, = ax1.plot(x_ax, df['Pout (W) @ optSolInd=23'], color=basecolors[0], lw=lwidth)
PlotOPSvelocity, = ax3.plot(x_ax, df['v (m/s) @ optSolInd=23'], label='Velocity', color=basecolors[1], lw=lwidth)


# TIME STAMPS AND CONSTRAINT VALUE
##########################################
x20, y2max = ax2.get_xlim()[1], ax2.get_ylim()[1]

ytop = .921
xdiff = .2
xcenter=.515

toptext =  ax3.text(x=xcenter, y=ytop, s=r'$f_\mathrm{{bench.}} = {:.1f}\, \mathrm{{s}} \qquad f_\mathrm{{opt.}} = {:.1f}\, \mathrm{{s}} \qquad g = {:.0f}\, \mathrm{{W}} $'
                        .format(df['T (s) @ optSolInd=0'][0], df['T (s) @ optSolInd=23'][0], df['PTnorm @ optSolInd=0'][0]),
                        ha='center', va='top', transform=fig.transFigure, fontsize=fsize)


# TEXT POWER AND VELCOCITY
########################################
xpos1 = .5
xpos2=.67

TextCPSvelocity = ax3.text(x=1.3, y=15, s='Benchmark velocity', fontsize=sfsize, color=basecolors[1], alpha=fade)
TextOPSvelocity = ax3.text(x=.05, y=16, s='Optimized velocity', fontsize=sfsize, color=basecolors[1])

TextCPSpower = ax1.text(x=xpos1, y=460, s='Benchmark power', color=basecolors[0], fontsize=sfsize, alpha=fade)
TextOPSpower = ax1.text(x=xpos1, y=400, s='Optimized power', color=basecolors[0], fontsize=sfsize)

hwidth2=.02
hlength2=.2
ax3.arrow(x=.4, y=13.5, dx=0, dy=2, linewidth=lwidth, color=basecolors[1],
            alpha=1, head_width=hwidth2, head_length=hlength2)

ax3.arrow(x=1.85, y=13.5, dx=0, dy=1, linewidth=lwidth, color=basecolors[1],
            alpha=fade, head_width=hwidth2, head_length=hlength2)



plt.savefig('fig5d.pdf', dpi=1600)
