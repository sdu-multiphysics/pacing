import numpy as np
import pandas as pd


file = 'Data - optimal pacing strategy - Martin Toft Madsen - 3211_2020-08-01-09-32-00.csv'

df_all = pd.read_csv(file, header=0)
df = df_all.drop_duplicates(subset=['Distance_miles'])



# input to comsol
height = np.transpose(np.array([df['Distance_miles']*1.60934*1000, df['Altitude']]))
power = np.transpose(np.array([df['Distance_miles']*1.60934*1000, df['Power']]))



np.savetxt('MTM_height.csv', height, delimiter=',')
np.savetxt('MTM_power.csv', power, delimiter=',')



# L = 21324 m
